# tools/transcript.py
#
# Fixed for youtube-transcript-api >= 0.6.0
# The old class-method API (list_transcripts) was removed.
# The simple get_transcript() class method still works and is cleaner anyway.

from youtube_transcript_api import YouTubeTranscriptApi, NoTranscriptFound, TranscriptsDisabled


def get_transcript(video_id: str, max_chars: int = 8000) -> dict:
    """
    Fetch the transcript for a YouTube video.
    Uses the simple get_transcript() method which works across all recent versions.
    """
    # Languages to try in order of preference
    languages_to_try = [
        ['en'],
        ['en-US'],
        ['en-GB'],
        ['en-CA'],
        ['en-AU'],
    ]

    transcript_data = None

    for languages in languages_to_try:
        try:
            transcript_data = YouTubeTranscriptApi.get_transcript(
                video_id,
                languages=languages
            )
            break  # Success — stop trying other languages
        except NoTranscriptFound:
            continue  # Try next language variant
        except TranscriptsDisabled:
            return {
                "video_id": video_id,
                "transcript": None,
                "error": "Transcripts are disabled for this video",
            }
        except Exception:
            continue

    # If all language attempts failed, try without specifying language
    if transcript_data is None:
        try:
            transcript_data = YouTubeTranscriptApi.get_transcript(video_id)
        except Exception as e:
            return {
                "video_id": video_id,
                "transcript": None,
                "error": f"No transcript available: {str(e)}",
            }

    # Join all chunks into one readable string
    # Each chunk looks like: {"text": "hello world", "start": 0.0, "duration": 2.5}
    full_text = " ".join(
        chunk.get("text", "") if isinstance(chunk, dict) else chunk.text
        for chunk in transcript_data
    )

    # Clean up common artifacts
    full_text = full_text.replace("\n", " ").replace("[Music]", "").strip()

    # Cap length to avoid overwhelming the context window
    if len(full_text) > max_chars:
        full_text = full_text[:max_chars] + "... [truncated]"

    return {
        "video_id": video_id,
        "transcript": full_text,
        "char_count": len(full_text),
        "is_truncated": len(full_text) >= max_chars,
    }
